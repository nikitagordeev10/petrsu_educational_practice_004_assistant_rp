API_TOKEN=""
PARSE_URL="https://ru.wikipedia.org/wiki/Городские_населённые_пункты_Московской_области"
